//
// Created by Petar on 18.6.2023 г..
//

#include "startUp.h"
#include "ExcelTableMenu.h"

void run() {
    ExcelTableMenu menu;
    menu.processTheProgram();
}
