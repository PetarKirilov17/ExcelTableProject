//
// Created by Petar on 18.6.2023 г..
//

#ifndef EXCELTABLEPROJECT_STARTUP_H
#define EXCELTABLEPROJECT_STARTUP_H

void run();

#endif //EXCELTABLEPROJECT_STARTUP_H
