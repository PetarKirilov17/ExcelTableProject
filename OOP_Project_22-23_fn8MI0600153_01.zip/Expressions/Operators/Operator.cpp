//
// Created by Petar on 15.6.2023 г..
//

#include "Operator.h"

bool Operator::isOperator() const {
    return true;
}
