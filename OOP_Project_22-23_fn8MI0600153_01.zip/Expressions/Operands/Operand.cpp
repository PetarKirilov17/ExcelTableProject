//
// Created by Petar on 15.6.2023 г..
//

#include "Operand.h"

bool Operand::isOperator() const {
    return false;
}
