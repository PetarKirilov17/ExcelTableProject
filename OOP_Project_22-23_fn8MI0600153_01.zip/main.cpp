#include "startUp.h"
int main() {
    run();
}